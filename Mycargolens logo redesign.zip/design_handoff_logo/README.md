# Handoff: MyCargoLens — new logo ("Focus Frame")

## Overview
This package contains the **new MyCargoLens brand mark** and everything needed to
replace the old logo across the app (`app.mycargolens.com`), the marketing site,
favicons, OG images, and OS/app icons.

The old mark — a six-blade camera aperture with a gold hexagonal center — is
**retired**. The new mark is the **Focus Frame**: four corner brackets in navy
with a single gold "subject" square locked in the center. It reads as a reticle
locking onto the one filing that matters — the product's triage thesis — and it
stays crisp from a 1584px banner down to a 16px favicon.

## About the design files
The SVGs in `assets/` are **production-ready, final vector source** — not
throwaway prototypes. They can be shipped as-is or pasted into a React/Vue
component. The `_preview.html` and `LogoGuidelines.png` files are **references
only** (a visual spec sheet); do not ship them. Recreate/replace the logo using
your codebase's existing conventions (e.g. an inline SVG component, an imported
`.svg`, or your icon system) — match these vectors exactly.

## Fidelity
**High-fidelity.** Colors, geometry, and proportions are final. Reproduce the
vectors exactly; do not redraw by eye or re-space the brackets.

---

## The assets (`assets/`)

| File | Use | Notes |
|---|---|---|
| `logo-mark.svg` | Primary mark, light backgrounds | Navy frame + gold subject |
| `logo-mark-mono.svg` | Single-color contexts (engraving, fax, one-ink print) | All navy |
| `logo-mark-reversed.svg` | Dark / navy backgrounds | Light-grey frame + gold subject |
| `app-icon.svg` | OS app icon, OG card, avatar | Navy rounded tile, light frame, gold subject |
| `favicon.svg` | Browser tab (16–32px) | Thicker stroke tuned for tiny sizes |
| `wordmark.svg` | Horizontal lockup (mark + "MyCargoLens") | Text uses **Inter 700**; see note below |

> **Wordmark text:** `wordmark.svg` renders the word with live `Inter` text, so it
> needs Inter available (you already load it). If you need a font-independent
> asset (e.g. email signatures), outline the text to paths in your vector tool,
> or — preferred in-app — render the **mark SVG + an HTML/JSX text node** rather
> than the combined SVG, so the type inherits your app's font stack.

---

## Geometry (canonical — rebuild from this, don't eyeball)

All coordinates on a **100 × 100** canvas (`viewBox="0 0 100 100"`).

**Frame — four corner brackets**, `stroke-width="6.4"`, `stroke-linecap="round"`,
`stroke-linejoin="round"`, `fill="none"`:
```
M 26 40 L 26 26 L 40 26      (top-left)
M 60 26 L 74 26 L 74 40      (top-right)
M 74 60 L 74 74 L 60 74      (bottom-right)
M 40 74 L 26 74 L 26 60      (bottom-left)
```
- Brackets inset 26 units from the edge; each arm is 14 units long.

**Subject — the gold square:**
```
<rect x="42" y="42" width="16" height="16" rx="4.6" />
```
- 16 × 16, centered, corner radius 4.6.
- The subject is the **only** gold element. Never add a second gold.

**Favicon tweak:** at 16–32px the stroke is bumped to `8` and the brackets
inset to give the tiny rendering more weight (see `favicon.svg`). Subject `rx`
drops to `4`.

---

## Design tokens (colors)

| Token | Hex | HSL | Used for |
|---|---|---|---|
| Navy (primary / frame) | `#1E2D4D` | `hsl(222 47% 22%)` | The frame on light backgrounds; mono mark |
| Gold (accent / subject) | `#FBBE24` | `hsl(43 96% 56%)` | The subject square — the one accent |
| Gold (text on light) | `#D8920F` | `hsl(38 92% 44%)` | "Lens" in the wordmark on light backgrounds |
| Navy tile bg | `#14213D` | `hsl(222 47% 9%)` | App-icon tile background |
| Frame on dark | `#8C99B8` | `hsl(222 30% 64%)` | Reversed mark + tile frame |

Two-color discipline: **navy anchors, gold accents, nothing else.** No gradients,
no third color, no shadows inside the mark.

---

## Wordmark typography
- Typeface: **Inter**, weight **700** (Bold).
- Tracking: `-0.025em` (the SVG uses `letter-spacing="-1.1"` at 42px, equivalent).
- Casing: always one word, camel-case **"MyCargoLens"** — never spaced, hyphenated,
  or all-caps.
- Color split: `MyCargo` in navy, `Lens` in gold (`#D8920F` on light, `#FBBE24`
  on dark). Never recolor beyond this split.

---

## Usage rules

**Clear space:** keep empty space equal to one bracket arm (14 units, i.e. 14% of
the mark's width) on all sides. Nothing enters that zone.

**Minimum size:** mark ≥ 20px on screen (use `favicon.svg` at 16px); full lockup
≥ ~150px wide on screen, ≥ 22mm in print.

**Do not:**
- recolor the frame or use a second gold
- rotate, skew, or stretch (keep the aspect ratio 1:1 for the mark)
- add shadows, gradients, glows, or strokes to the subject
- redraw or re-space the brackets — always use these vectors

---

## Where the logo lives in the app (replace all of these)
Search the codebase for the **old aperture mark** and the wordmark, typically:
- App header / sidebar logo component
- `favicon.ico` / `favicon.svg` / `apple-touch-icon.png` in `public/`
- Web app manifest icons (`manifest.json` / `site.webmanifest`)
- OG / social share image generation
- Auth / login screen, loading splash, empty states
- Email templates, PDF/report headers
- Marketing site nav + footer

Swap each for the matching asset above (light vs. dark context decides
`logo-mark.svg` vs. `logo-mark-reversed.svg`).

## Files in this bundle
- `assets/logo-mark.svg`, `logo-mark-mono.svg`, `logo-mark-reversed.svg`,
  `app-icon.svg`, `favicon.svg`, `wordmark.svg` — **ship these**
- `_preview.html` — visual contact sheet (reference only)
- `LogoGuidelines.png` — full spec sheet image (reference only)
